import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, ExternalLink } from "lucide-react";

export default function Creative() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  const portfolioItems = [
    {
      src: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2F4672664b34c24d49a229571faeff40a8?format=webp&width=800",
      title: "Andala Rakshasi",
      caption: "Film Poster Design",
      type: "poster"
    },
    {
      src: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2F7af68e186fb842cdb1fe99eb63cb45e7?format=webp&width=800",
      title: "Memories",
      caption: "Typography & Visual Storytelling",
      type: "poster"
    },
    {
      src: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2F2c3a389129f9466dbe0583abf05b177a?format=webp&width=800",
      title: "Mahanati",
      caption: "Character Portrait Design",
      type: "poster"
    },
    {
      src: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2F8f8b046585074a2bbb26b50772a7aa96?format=webp&width=800",
      title: "Dear Comrade",
      caption: "Emotional Storytelling Through Design",
      type: "poster"
    },
    {
      src: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2Feda6ff8c11d8494196e5a4887ac7aa80?format=webp&width=800",
      title: "Silence Is Luxury",
      caption: "Minimalist Typography Design",
      type: "poster"
    },
    {
      src: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2Fe4ac2c007a194bdf8de2dbdbc1416758?format=webp&width=800",
      title: "Surya Son of Krishnan",
      caption: "Dynamic Character Composition",
      type: "poster"
    }
  ];

  const creativeTools = [
    { name: "Photoshop", color: "from-blue-500 to-purple-600", delay: "0s" },
    { name: "Figma", color: "from-purple-500 to-pink-500", delay: "0.1s" },
    { name: "Premiere Pro", color: "from-pink-500 to-red-500", delay: "0.2s" },
    { name: "DaVinci Resolve", color: "from-orange-500 to-yellow-500", delay: "0.3s" }
  ];

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    const handleScroll = () => {
      const scrolled = window.pageYOffset;
      const rate = scrolled * -0.5;
      
      if (titleRef.current) {
        titleRef.current.style.transform = `translateY(${rate}px)`;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);

    // Intersection Observer for scroll animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    // Observe all portfolio items and animated elements
    document.querySelectorAll('.scroll-reveal').forEach((el) => {
      observer.observe(el);
    });

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      observer.disconnect();
    };
  }, []);

  return (
    <div className="bg-black text-white overflow-hidden">
      {/* Custom CSS for animations */}
      <style>{`
        .scroll-reveal {
          opacity: 0;
          transform: translateY(100px);
          transition: all 1.2s cubic-bezier(0.165, 0.84, 0.44, 1);
        }
        
        .scroll-reveal.animate-in {
          opacity: 1;
          transform: translateY(0);
        }
        
        .portfolio-item {
          transition: all 0.8s cubic-bezier(0.165, 0.84, 0.44, 1);
          transform-origin: center;
        }
        
        .portfolio-item:hover {
          transform: scale(1.02);
        }
        
        .portfolio-item:hover .portfolio-overlay {
          opacity: 1;
        }
        
        .portfolio-overlay {
          opacity: 0;
          transition: opacity 0.6s ease;
        }
        
        .tool-item {
          transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
          animation-delay: var(--delay);
        }
        
        .tool-item:hover {
          transform: translateY(-10px) rotate(2deg);
        }
        
        .parallax-text {
          will-change: transform;
        }
        
        .magnetic-button {
          transition: transform 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
        }
        
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(60px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .fade-in-up {
          animation: fadeInUp 1.5s cubic-bezier(0.165, 0.84, 0.44, 1);
        }
      `}</style>

      {/* Hero Section */}
      <section ref={heroRef} className="h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-pink-900/20"></div>
        
        {/* Floating elements */}
        <div 
          className="absolute w-96 h-96 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full blur-3xl"
          style={{
            transform: `translate(${mousePosition.x * 0.02}px, ${mousePosition.y * 0.02}px)`
          }}
        ></div>
        
        <div className="text-center z-10 px-4">
          <h1 
            ref={titleRef}
            className="parallax-text text-7xl md:text-9xl font-black mb-6 bg-gradient-to-r from-white via-purple-200 to-pink-200 bg-clip-text text-transparent fade-in-up"
          >
            VISUAL
          </h1>
          <h2 className="text-6xl md:text-8xl font-light mb-8 fade-in-up" style={{ animationDelay: '0.3s' }}>
            STORYTELLER
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto fade-in-up" style={{ animationDelay: '0.6s' }}>
            Crafting cinematic narratives through design, motion, and emotion
          </p>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full p-1">
            <div className="w-1 h-3 bg-white/50 rounded-full mx-auto animate-pulse"></div>
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20">
        {portfolioItems.map((item, index) => (
          <div key={index} className="scroll-reveal" style={{ transitionDelay: `${index * 0.1}s` }}>
            <a
              href="https://www.instagram.com/nvdfeed/"
              target="_blank"
              rel="noopener noreferrer"
              className="block portfolio-item group"
            >
              <div className="relative h-screen flex items-center justify-center px-4 md:px-20">
                <div className="w-full max-w-6xl">
                  <div className="grid md:grid-cols-2 gap-12 items-center">
                    <div className={`${index % 2 === 0 ? 'order-1' : 'order-2'}`}>
                      <div className="relative overflow-hidden rounded-2xl">
                        <img
                          src={item.src}
                          alt={item.title}
                          className="w-full h-auto object-cover transform transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="portfolio-overlay absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-8">
                          <ExternalLink className="w-8 h-8 text-white" />
                        </div>
                      </div>
                    </div>
                    
                    <div className={`${index % 2 === 0 ? 'order-2' : 'order-1'} space-y-6`}>
                      <div className="space-y-4">
                        <span className="text-purple-400 text-sm font-medium tracking-wider uppercase">
                          {item.type}
                        </span>
                        <h3 className="text-4xl md:text-6xl font-bold">
                          {item.title}
                        </h3>
                        <p className="text-xl text-gray-300">
                          {item.caption}
                        </p>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-purple-400">
                        <span>View on Instagram</span>
                        <ExternalLink className="w-5 h-5" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        ))}
      </section>

      {/* Creative Toolkit Section */}
      <section className="py-32 scroll-reveal">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-5xl md:text-7xl font-bold mb-20 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            CREATIVE TOOLKIT
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {creativeTools.map((tool, index) => (
              <div
                key={tool.name}
                className="tool-item"
                style={{ '--delay': tool.delay } as React.CSSProperties}
              >
                <Card className="bg-gradient-to-br from-gray-900 to-black border-gray-800 hover:border-purple-500/50 transition-all duration-500">
                  <CardContent className="p-8 text-center">
                    <div className={`w-16 h-16 mx-auto mb-6 bg-gradient-to-r ${tool.color} rounded-2xl flex items-center justify-center`}>
                      <div className="w-8 h-8 bg-white rounded-lg"></div>
                    </div>
                    <h3 className="text-xl font-semibold text-white">{tool.name}</h3>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="min-h-screen flex items-center justify-center scroll-reveal">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-6xl md:text-8xl font-black mb-12 bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
            LET'S MAKE<br />SOMETHING COOL.
          </h2>
          
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Ready to create something extraordinary? Drop me a message and let's bring your vision to life.
          </p>
          
          <Card className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 border-purple-500/30 backdrop-blur-sm max-w-lg mx-auto">
            <CardContent className="p-8">
              <form className="space-y-6">
                <div>
                  <Input
                    placeholder="Your Name"
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-400 focus:border-purple-500"
                  />
                </div>
                <div>
                  <Input
                    type="email"
                    placeholder="Your Email"
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-400 focus:border-purple-500"
                  />
                </div>
                <div>
                  <Textarea
                    placeholder="Tell me about your project..."
                    rows={4}
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-400 focus:border-purple-500"
                  />
                </div>
                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-4 magnetic-button"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  Start the Conversation
                </Button>
              </form>
            </CardContent>
          </Card>
          
          <div className="mt-12">
            <a
              href="https://www.instagram.com/nvdfeed/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 text-purple-400 hover:text-purple-300 transition-colors"
            >
              <span>Follow the journey</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
