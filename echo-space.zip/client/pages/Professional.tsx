import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Download, Linkedin, Mail, Sparkles, FileText, ExternalLink, Calendar, MapPin, Building } from "lucide-react";
import { useState } from "react";

export default function Professional() {
  const [summaries, setSummaries] = useState<{[key: string]: string}>({});
  const [loadingSummary, setLoadingSummary] = useState<string | null>(null);

  const skills = [
    "SQL", "Power BI", "Microsoft Excel", "Python", "Tableau", 
    "Machine Learning", "Generative AI"
  ];

  const certifications = [
    { name: "Career Essentials in Data Analysis", issuer: "Microsoft & LinkedIn" },
    { name: "Data Analytics Job Simulation", issuer: "Deloitte Australia" },
    { name: "Introduction to Transact-SQL", issuer: "Microsoft" },
    { name: "Power BI for Beginners", issuer: "Simplilearn" },
    { name: "Data Visualisation Job Simulation", issuer: "Tata" },
    { name: "GenAI Powered Data Analytics Job Simulation", issuer: "Tata" },
    { name: "No Code AI Agent Builder", issuer: "Simplilearn" },
    { name: "CS105: Introduction to Python", issuer: "Saylor Academy" },
    { name: "Learning Data Analytics: Foundations", issuer: "LinkedIn" },
    { name: "BUS210: Business Communication", issuer: "Saylor Academy" }
  ];

  const experiences = [
    {
      id: "vagarious-solutions",
      company: "Vagarious Solutions Pvt Ltd",
      role: "Research Analyst",
      type: "Internship",
      duration: "May 2025 – Present (4 months)",
      location: "Madhapur · On-site",
      logo: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2F9fd3b57013c949e992769c69520b356f?format=webp&width=800",
      description: "Eager to immerse myself in the dynamic world of research and analytics at Vagarious Solutions in Hyderabad, I'm excited to contribute my analytical mindset and attention to detail in uncovering insights, supporting data-driven strategies, and identifying emerging trends within the fast-evolving technology sector. I'm keen to learn from experienced professionals and make a meaningful impact through in-depth research and actionable recommendations during this internship."
    },
    {
      id: "shoppers-stop",
      company: "Shoppers Stop",
      role: "Operations Intern",
      type: "Internship",
      duration: "July 2023 – Sept 2023 (3 months)",
      location: "On-site",
      logo: "https://cdn.builder.io/api/v1/image/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2F49c26b40bc28428f91229a443de38dff?format=webp&width=800",
      description: "Through interacting with various customers and planning events that attract and engage customers effectively, I was able to gather very important insights about how retail operations work."
    }
  ];

  const projects = [
    {
      id: "ai-agent",
      title: "AI Agent for Data Analysis Using n8n & LangChain",
      description: "Designed and built a custom AI agent to automate multi-sheet Excel analysis across 15+ industry datasets. Integrated n8n, LangChain, OpenAI Whisper, and Gemini Pro to support voice/text inputs and contextual AI responses. Developed a Telegram Bot interface for seamless interaction and automated workflows using Gmail and Google Sheets for real-time reporting. The solution minimized manual effort, enhanced analysis speed, and supported decision-making during the internship project."
    },
    {
      id: "market-strategy",
      title: "AI-Enhanced Market Strategy for Wearable Fitness Tracker",
      description: "Performed AI-driven competitor analysis using ChatGPT to assess key players in the wearable fitness tracker market. Conducted SWOT analysis to identify strengths, weaknesses, opportunities, and threats for each competitor. Analyzed market trends like stress management and AI-IoT integration to identify growth opportunities. Formulated a market entry strategy, recommending differentiation tactics to capture targeted demographics."
    },
    {
      id: "customer-insights",
      title: "AI-Powered Customer Insights Optimization using ChatGPT",
      description: "Leveraged ChatGPT for sentiment analysis and trend identification on 500+ customer reviews. Developed insights on top customer issues and appreciated product features, presented through charts and tables. Generated strategic recommendations to enhance customer experience and improve sales based on actionable insights."
    },
    {
      id: "telugu-movies",
      title: "Data-Driven Analysis of Telugu Movie Genres (SQL & Tableau)",
      description: "This project analyzes 1500+ Telugu movies to uncover trends in genres, audience ratings, and runtime. SQL was used to clean and query the IMDb dataset, while Tableau brought those insights to life through interactive visuals. The project combines analytical thinking with storytelling to bridge the gap between data and viewer behavior."
    }
  ];

  const certificationFiles = [
    {
      id: "data-analysis-cert",
      name: "Career Essentials in Data Analysis",
      issuer: "Microsoft & LinkedIn",
      fileType: "PDF",
      downloadUrl: "#"
    },
    {
      id: "deloitte-simulation",
      name: "Data Analytics Job Simulation",
      issuer: "Deloitte Australia",
      fileType: "PDF",
      downloadUrl: "#"
    },
    {
      id: "sql-cert",
      name: "Introduction to Transact-SQL",
      issuer: "Microsoft",
      fileType: "PDF",
      downloadUrl: "#"
    },
    {
      id: "powerbi-cert",
      name: "Power BI for Beginners",
      issuer: "Simplilearn",
      fileType: "PDF",
      downloadUrl: "#"
    },
    {
      id: "tata-visualization",
      name: "Data Visualisation Job Simulation",
      issuer: "Tata",
      fileType: "PDF",
      downloadUrl: "#"
    },
    {
      id: "tata-genai",
      name: "GenAI Powered Data Analytics Job Simulation",
      issuer: "Tata",
      fileType: "PDF",
      downloadUrl: "#"
    }
  ];

  const generateSummary = async (projectId: string, title: string, description: string) => {
    setLoadingSummary(projectId);

    // Simulate AI summary generation
    await new Promise(resolve => setTimeout(resolve, 2000));

    const summaryTexts = {
      "ai-agent": "Built an innovative AI-powered automation solution that revolutionized Excel analysis workflows across multiple industry datasets, incorporating cutting-edge technologies like n8n, LangChain, and Gemini Pro for enhanced productivity and decision-making.",
      "market-strategy": "Conducted comprehensive AI-driven market research for wearable fitness trackers, delivering strategic insights through competitor analysis, SWOT evaluation, and market trend identification to inform effective market entry strategies.",
      "customer-insights": "Transformed customer feedback into actionable business intelligence using advanced AI sentiment analysis, processing 500+ reviews to generate strategic recommendations that drive customer experience improvements and sales growth.",
      "telugu-movies": "Analyzed 1,500+ Telugu films using SQL and Tableau to reveal compelling industry insights about genre preferences, ratings patterns, and runtime trends, demonstrating the power of data storytelling in entertainment analytics."
    };

    setSummaries(prev => ({
      ...prev,
      [projectId]: summaryTexts[projectId as keyof typeof summaryTexts] || "AI-generated summary of this innovative project showcasing advanced technical skills and practical application of data analytics in real-world scenarios."
    }));
    setLoadingSummary(null);
  };

  const downloadResume = () => {
    const resumeUrl = "https://cdn.builder.io/o/assets%2Ff8f21941f1e648c98a0bb03a9b5810f1%2Fbc141d30ab3a4d57b335343975ea4760?alt=media&token=7edeb33e-1014-416c-a9a6-2a7db2430513&apiKey=f8f21941f1e648c98a0bb03a9b5810f1";

    // Create a temporary anchor element to trigger the download
    const link = document.createElement('a');
    link.href = resumeUrl;
    link.download = 'D.S.NarayanaRaju_Resume.pdf'; // Set the filename for download
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadCertification = (cert: typeof certificationFiles[0]) => {
    // For now, we'll use placeholder behavior since actual cert files aren't provided
    // In a real implementation, this would download the actual certification file
    alert(`Downloading ${cert.name} certificate...`);
  };

  return (
    <div className="bg-gradient-to-br from-slate-50 to-white min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
            D.S. Narayana Raju
          </h1>
          <p className="text-lg md:text-xl text-blue-600 font-medium mb-6">
            Business Analytics Student | Data-driven Problem Solver
          </p>
          <p className="max-w-3xl mx-auto text-gray-600 mb-8">
            A dedicated and analytical Business Analytics student with a strong foundation in data analysis, 
            visualization, and machine learning. Passionate about transforming complex datasets into actionable 
            insights and strategic recommendations.
          </p>
          
          <div className="flex justify-center items-center space-x-4 mb-8">
            <Button
              size="lg"
              onClick={downloadResume}
              className="gap-2 bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              Download Resume
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              asChild
              className="gap-2"
            >
              <a 
                href="https://www.linkedin.com/in/dendukuri-sai-narayana-raju-b5b376342/" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <Card className="text-center">
              <CardContent className="p-6">
                <h3 className="text-3xl font-bold text-blue-600 mb-2">10+</h3>
                <p className="text-gray-600">Certifications</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <h3 className="text-3xl font-bold text-blue-600 mb-2">5+</h3>
                <p className="text-gray-600">Data Projects</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <h3 className="text-3xl font-bold text-blue-600 mb-2">4</h3>
                <p className="text-gray-600">Key Analytics Tools</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <h3 className="text-3xl font-bold text-blue-600 mb-2">2</h3>
                <p className="text-gray-600">Internships</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Education & Certifications */}
      <section className="py-16 px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-5 gap-12">
            <div className="md:col-span-2">
              <h2 className="text-3xl font-bold text-center mb-8">Education</h2>
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-lg">Siva Sivani Institute Of Management</h3>
                    <p className="text-gray-600">PGDM, Business Analytics (2022-2024)</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-lg">Westin Business School</h3>
                    <p className="text-gray-600">BBA, Business Administration (2021-2024)</p>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            <div className="md:col-span-3">
              <h2 className="text-3xl font-bold text-center mb-8">Licenses & Certifications</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {certifications.map((cert, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-sm mb-1">{cert.name}</h3>
                      <p className="text-xs text-gray-500">{cert.issuer}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-16 px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Skills & Tools</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {skills.map((skill) => (
              <Badge
                key={skill}
                variant="secondary"
                className="px-4 py-2 text-md font-medium bg-blue-100 text-blue-800"
              >
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* Professional Experience Section */}
      <section className="py-16 px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Professional Experience</h2>
          <div className="space-y-8">
            {experiences.map((experience, index) => (
              <Card key={experience.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className="grid md:grid-cols-3 gap-6 p-6">
                    {/* Left Column - Company Info */}
                    <div className="md:col-span-1 flex flex-col items-center md:items-start text-center md:text-left">
                      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center mb-4 overflow-hidden">
                        <img
                          src={experience.logo}
                          alt={`${experience.company} logo`}
                          className="w-12 h-12 object-contain"
                          onError={(e) => {
                            // Fallback to building icon if logo fails to load
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            target.nextElementSibling?.classList.remove('hidden');
                          }}
                        />
                        <Building className="w-8 h-8 text-gray-400 hidden" />
                      </div>

                      <h3 className="font-bold text-lg text-gray-900 mb-1">{experience.company}</h3>
                      <p className="text-blue-600 font-semibold mb-2">{experience.role}</p>
                      <Badge variant="outline" className="mb-3 text-xs">
                        {experience.type}
                      </Badge>

                      <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex items-center justify-center md:justify-start gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{experience.duration}</span>
                        </div>
                        <div className="flex items-center justify-center md:justify-start gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{experience.location}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right Column - Description */}
                    <div className="md:col-span-2">
                      <div className="prose prose-gray max-w-none">
                        <p className="text-gray-700 leading-relaxed">
                          {experience.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Project Showcase</h2>
          <Accordion type="single" collapsible className="space-y-4">
            {projects.map((project) => (
              <AccordionItem key={project.id} value={project.id} className="border rounded-lg">
                <AccordionTrigger className="px-6 py-4 text-left">
                  <span className="font-semibold">{project.title}</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <p className="text-gray-700 mb-4">{project.description}</p>
                  <div className="flex items-center gap-4">
                    <Button
                      size="sm"
                      onClick={() => generateSummary(project.id, project.title, project.description)}
                      disabled={loadingSummary === project.id}
                      className="gap-2 bg-blue-500 hover:bg-blue-600"
                    >
                      <Sparkles className="w-4 h-4" />
                      {loadingSummary === project.id ? "Generating..." : "Generate Summary"}
                    </Button>
                  </div>
                  {summaries[project.id] && (
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                      <p className="text-gray-600 italic">{summaries[project.id]}</p>
                    </div>
                  )}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 px-6 lg:px-8 bg-gray-50">
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Get In Touch</h2>
          <Card>
            <CardContent className="p-6">
              <form className="space-y-6">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input id="name" type="text" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="message">Message</Label>
                  <Textarea id="message" rows={4} className="mt-1" />
                </div>
                <div className="text-center">
                  <Button type="submit" size="lg" className="gap-2 bg-blue-600 hover:bg-blue-700">
                    <Mail className="w-4 h-4" />
                    Send Message
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
