import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <div className="min-h-screen bg-background">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link
              to="/"
              className="text-2xl font-bold text-gray-900 hover:opacity-80 transition-opacity"
            >
              D.S. Narayana Raju
            </Link>
            
            <div className="flex items-center space-x-1">
              <Button
                variant={isActive("/") ? "default" : "ghost"}
                asChild
                className={cn(
                  "relative px-4 py-2 text-sm font-medium transition-all duration-300 border-b-2",
                  isActive("/")
                    ? "border-blue-500 text-gray-700"
                    : "border-transparent text-gray-500 hover:text-gray-900"
                )}
              >
                <Link to="/">
                  Professional
                </Link>
              </Button>
              
              <Button
                variant={isActive("/creative") ? "default" : "ghost"}
                asChild
                className={cn(
                  "relative px-4 py-2 text-sm font-medium transition-all duration-300 border-b-2",
                  isActive("/creative")
                    ? "border-purple-500 text-gray-700"
                    : "border-transparent text-gray-500 hover:text-gray-900"
                )}
              >
                <Link to="/creative">
                  Creative
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>
      
      <main className="pt-16">
        {children}
      </main>
    </div>
  );
}
